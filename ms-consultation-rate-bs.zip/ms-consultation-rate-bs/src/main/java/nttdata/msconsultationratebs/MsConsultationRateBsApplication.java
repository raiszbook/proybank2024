package nttdata.msconsultationratebs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsConsultationRateBsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsConsultationRateBsApplication.class, args);
	}

}
