package nttdata.mstransaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
